* This is an example code for the algorithm described in

"Hyperspectral Image Classification with Robust Sparse Representation. Chang Li, Yong Ma, Xiaoguang Mei, Chengyin Liu, and Jiayi Ma. IEEE Geoscience and Remote Sensing Letters: 2016 ,5/13".