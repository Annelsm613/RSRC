function X = Get_neighbour( Y,Xtest_pos,neighbour)
[M,N,B]=size(Y);
Num=size(Xtest_pos,1);
X = cell( 1,Num);

for k=1:Num
    if rem(neighbour,2)==1
        if Xtest_pos(k,1)>=(neighbour+1)/2 & Xtest_pos(k,1)<=M-(neighbour+1)/2 & Xtest_pos(k,2)>=(neighbour+1)/2 & Xtest_pos(k,2)<=N-(neighbour+1)/2
            temp=[];
            for i=-(neighbour-1)/2:(neighbour-1)/2
                for j=-(neighbour-1)/2:(neighbour-1)/2
                    t=reshape(Y(Xtest_pos(k,1)+i,Xtest_pos(k,2)+j,:),B,1);
                    temp=[temp t];
                end
            end
        else
            temp=[];
            for i=-(neighbour-1)/2:(neighbour-1)/2
                for j=-(neighbour-1)/2:(neighbour-1)/2
                    t=reshape(Y(min(max(Xtest_pos(k,1),(neighbour+1)/2),M-(neighbour+1)/2)+i,min(max(Xtest_pos(k,2),(neighbour+1)/2),N-(neighbour+1)/2)+j,:),B,1);
                    temp=[temp t];
                end
            end
        end
        X{k}=temp;
    else
        if Xtest_pos(k,1)>=neighbour/2 & Xtest_pos(k,1)<=M-neighbour/2 & Xtest_pos(k,2)>=neighbour/2 & Xtest_pos(k,2)<=N-neighbour/2
            temp=[];
            for i=-neighbour/2+1:neighbour/2
                for j=-neighbour/2+1:neighbour/2
                    t=reshape(Y(Xtest_pos(k,1)+i,Xtest_pos(k,2)+j,:),B,1);
                    temp=[temp t];
                end
            end
        else
            temp=[];
            for i=-neighbour/2+1:neighbour/2
                for j=-neighbour/2+1:neighbour/2
                    t=reshape(Y(min(max(Xtest_pos(k,1),neighbour/2),M-neighbour/2)+i,min(max(Xtest_pos(k,2),neighbour/2),N-neighbour/2)+j,:),B,1);
                    temp=[temp t];
                end
            end
        end
        X{k}=temp;
    end
end
X=cell2mat(X);


end