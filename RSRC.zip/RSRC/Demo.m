clc;
clear all;
close all;
warning off;
addpath(genpath(cd));
load Indian_pines_gt.mat;

indian_pines=double(imread('92AV3C.tif'));
indian_pines=indian_pines(:,:,setdiff(1:220,[104:108 150:163 220]));
[M,N,B]=size(indian_pines);
Y_scale=scaleForSVM(reshape(indian_pines,M*N,B));
Y=reshape(Y_scale,M,N,B);
Result_select = Select_train_indain_pines1(Y,indian_pines_gt );

%RSRC
tic;
Class_predict1 = Class_predict_romp(Result_select,5*1e-6);
[OA1,Kappa1,AA1,CA1] = calcError( Result_select.Labeltest-1, Class_predict1-1, [1:16]);
t1=toc

%JRSRC
tic;
Class_predict2 = Class_predict_rsomp(Result_select,7,5*1e-5,Y);
[OA2,Kappa2,AA2,CA2] = calcError(Result_select.Labeltest-1, Class_predict2-1, [1:16]);
t2=toc