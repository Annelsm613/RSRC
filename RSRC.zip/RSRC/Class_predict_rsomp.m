function Class_predict = Class_predict_rsomp(Result_select,Neighbour_size,lambda,datacube)
Y=Result_select.Ytest;
D=Result_select.Ytrain;
pos=Result_select.Ytest_pos;
m=size(datacube,1);
Y_pos=Get_pos(pos,m);
Y_neighbour = Get_neighbour( datacube,Y_pos,Neighbour_size);
Num=size(Y,2);
D=D./repmat(sqrt(sum(D.^2)),[size(D,1) 1]);
Y_neighbour=Y_neighbour./repmat(sqrt(sum(Y_neighbour.^2)),[size(Y_neighbour,1) 1]);
[M,N,B]=size(datacube);
datacube=reshape(datacube,M*N,B)';
datacube=datacube./repmat(sqrt(sum(datacube.^2)),[size(datacube,1) 1]);
datacube=datacube';
datacube=reshape(datacube,M,N,B);
for i=1:Num
    param.lambda = lambda ;
    param.mode = 1 ;
    param.verbose = false ;
    alpha=mexLasso(Y_neighbour(:,Neighbour_size^2*(i-1)+1:Neighbour_size^2*i),[D eye(size(D,1))],param);
    beta=alpha((size(D,2)+1):end,:);
    for j=1:16
        res(j)=norm(Y_neighbour(:,Neighbour_size^2*(i-1)+1:Neighbour_size^2*i)-D(:,Result_select.Labeltrain==j)*alpha(Result_select.Labeltrain==j,:)-beta,'fro');
    end
    [temp,Class_predict(i)]=min(res);
end



