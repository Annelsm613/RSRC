function [Results] = Select_train_indain_pines1(X,Groundtruth )
[M,N,B]=size(X);
Xmat=reshape(X,M*N,B);
Y=reshape(Groundtruth,M*N,1);
class=unique(Y);
num=length(class);
Xtrain=[];
Ytrain=[];
Xtest=[];
Ytest=[];
Xtrain_pos=[];
Xtest_pos=[];
train=[15 100 100 50 50 100 15 50 15 100 150 50 50 100 50 50];%6 144 84 24 50 75 3 49 2 97 247 62 22 130 38 10
for i=2:num
    index=find(Y==class(i));
    total=length(index);
    Xtest_Num(1,i-1) = total - train(1,i-1);
    t=randperm(total);
    k=train(i-1);
    Xtrain=[Xtrain; Xmat(index(t(1:k)),:)];
    Ytrain=[Ytrain; Y(index(t(1:k)))];
    Xtest=[Xtest; Xmat(index(t((k+1):end)),:)];
    Ytest=[Ytest; Y(index(t((k+1):end)))];
    Xtrain_pos=[Xtrain_pos; index(t(1:k))];
    Xtest_pos=[Xtest_pos; index(t((k+1):end))];
end
Results.Ytrain=Xtrain';
Results.Labeltrain=Ytrain';
Results.Ytest=Xtest';
Results.Labeltest=Ytest';
Results.Ytrain_pos=Xtrain_pos;
Results.Ytest_pos=Xtest_pos;
Results.Ytest_Num=Xtest_Num;

end

