function Class_predict = Class_predict_romp(Result_select,lambda)
Y=Result_select.Ytest;
D=Result_select.Ytrain;
Num=size(Y,2);
D=D./repmat(sqrt(sum(D.^2)),[size(D,1) 1]);
Y=Y./repmat(sqrt(sum(Y.^2)),[size(Y,1) 1]);
for i=1:Num
    param.lambda = lambda ;
    param.mode = 1 ;
    param.verbose = false ;
    alpha=mexLasso(Y(:,i),[D eye(size(D,1))],param);
    beta=alpha(size(D,2)+1:end);
    for j=1:16
        res(1,j)=norm(Y(:,i)-D(:,Result_select.Labeltrain==j)*alpha(Result_select.Labeltrain==j));
    end
    [temp,Class_predict(1,i)]=min(res);
end



